import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
import tempfile
import os
from langchain.agents.agent_types import AgentType
from langchain_experimental.agents import create_csv_agent
from langchain_google_genai import ChatGoogleGenerativeAI

# Initialize Google Generative AI agent
google_api_key = "AIzaSyBSzPPmXU13kJDKcIfYA1djEXqgEtGdfGE"
model_name = "gemini-1.5-pro-latest"

def create_agent(csv_path):
    return create_csv_agent(
        ChatGoogleGenerativeAI(google_api_key=google_api_key, model=model_name),
        csv_path,
        verbose=True,
        agent_type=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
        allow_dangerous_code=True  # Enable this option explicitly
    )

# Function to read and parse CSV file
@st.cache_data
def read_csv(file):
    return pd.read_csv(file)

# Function to perform statistical analysis
def statistical_analysis(df):
    numerical_df = df.select_dtypes(include=['float64', 'int64'])
    stats = {
        'Mean': numerical_df.mean(),
        'Median': numerical_df.median(),
        'Mode': numerical_df.mode().iloc[0],
        'Standard Deviation': numerical_df.std(),
        'Variance': numerical_df.var(),
        'Min': numerical_df.min(),
        'Max': numerical_df.max(),
        'Correlation': numerical_df.corr()
    }
    return stats

# Function to generate plots
def generate_plots(df, columns):
    if columns:
        numerical_df = df[columns]
    else:
        numerical_df = df.select_dtypes(include=['float64', 'int64'])
    
    # Histogram
    st.write("Histograms:")
    hist_fig, hist_ax = plt.subplots()
    numerical_df.hist(ax=hist_ax, bins=15, edgecolor='black')
    st.pyplot(hist_fig)

    # Scatter plot
    st.write("Scatter Plot Matrix:")
    scatter_fig = sns.pairplot(numerical_df)
    st.pyplot(scatter_fig)

    # Line plot
    st.write("Line Plots:")
    line_fig, line_ax = plt.subplots()
    numerical_df.plot(ax=line_ax)
    st.pyplot(line_fig)

# Main function to run the data analysis and visualization
def main():
    st.title("CSV Data Analysis and Agent Query")

    # Initialize session state
    if 'mode' not in st.session_state:
        st.session_state.mode = None
        st.session_state.file_path = None

    # Mode selection buttons
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("Normal Analysis"):
            st.session_state.mode = "Normal Analysis"
    
    with col2:
        if st.button("Use LLM"):
            st.session_state.mode = "Use LLM"
    
    # Display file uploader and processing based on selected mode
    if st.session_state.mode:
        if st.session_state.mode == "Normal Analysis":
            file = st.file_uploader("Upload CSV file", type=["csv"])
            if file is not None:
                try:
                    # Save uploaded file to a temporary location
                    with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as tmp_file:
                        tmp_file.write(file.read())
                        tmp_file_path = tmp_file.name
                        st.session_state.file_path = tmp_file_path

                    df = read_csv(tmp_file_path)
                    st.success("File successfully uploaded and read!")

                    # Display the dataframe
                    st.write("Dataframe:")
                    st.dataframe(df)
                    
                    # Perform statistical analysis
                    stats = statistical_analysis(df)
                    st.write("Statistical Analysis:")
                    for key, value in stats.items():
                        st.write(f"**{key}**")
                        st.write(value)

                    # Generate plots
                    columns = st.multiselect("Select columns to plot:", df.columns, default=df.columns.tolist())
                    generate_plots(df, columns)

                except Exception as e:
                    st.error(f"Error processing file: {e}")

        elif st.session_state.mode == "Use LLM":
            st.write("## LLM Query")
            user_query = st.text_area("Enter your query for the agent:")
            
            if st.button("Get Response"):
                if user_query and st.session_state.file_path:
                    try:
                        agent = create_agent(st.session_state.file_path)
                        with st.spinner("Processing..."):
                            response = agent.invoke(user_query)
                        st.write("Agent Response:")
                        st.write(response)
                    except Exception as e:
                        st.error(f"Error getting response: {e}")
                elif not st.session_state.file_path:
                    st.warning("No file has been uploaded yet. Please upload a file using 'Normal Analysis' first.")
                else:
                    st.warning("Please enter a query.")

if __name__ == "__main__":
    main()
